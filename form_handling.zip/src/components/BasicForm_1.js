import useBasicInput from "../hooks/use-basicInput";

const BasicForm = () => {

  const {
    value: enteredFirstName,
    valueIsValid: enteredFirstNameIsValid,
    hasError: firstNameHasError,
    valueChangeHandler:firstNameChangeHandler,
    valueBlurHandler: firstNameBlurHandler,
    reset:resetFirstName
  } = useBasicInput((value) => value.trim() !== "");

  // last name

  const {
    value: enteredlastName,
    valueIsValid: enteredlastNameIsValid,
    hasError: lastNameHasError,
    valueChangeHandler: lastNameChangeHandler,
    valueBlurHandler: lastNameBlurHandler,
    reset:resetLastName
  } = useBasicInput((value) => value.trim() !== "");

  // Email

  const {
    value: enteredEmail,
    valueIsValid: enteredEmailIsValid,
    hasError: emailHasError,
    valueChangeHandler: emailChangeHandler,
    valueBlurHandler: emailBlurHandler,
    reset:resetEmail
  } = useBasicInput((value) => value.includes("@"));

  let formIsValid = false;
  if (enteredFirstNameIsValid && enteredlastNameIsValid && enteredEmailIsValid) {
      formIsValid = true;
  }
  const submitForm = (e) => {
    e.preventDefault();
    if(!enteredFirstNameIsValid){
       return;
    }
    console.log("first name", enteredFirstName , 'last name ', enteredlastName);
    resetFirstName();
    resetLastName();
    resetEmail();
  }
  const inputNameClasses = firstNameHasError ? "form-control invalid" : "form-control";
  const inputLastNameClasses = lastNameHasError ? "form-control invalid" : "form-control";
  const inputEmailClasses = emailHasError ? "form-control invalid" : "form-control";
  
  return (

    <form onSubmit={submitForm}>
      <div className='control-group'>
        <div className={inputNameClasses}>
          <label htmlFor='name'>First Name</label>
          <input type='text' value={enteredFirstName} id='name' onChange={firstNameChangeHandler} onBlur={firstNameBlurHandler} />
          { firstNameHasError && <p className="error-text">Enter first name is required</p>}
        </div>
        <div className={inputLastNameClasses}>
          <label htmlFor='name'>Last Name</label>
          <input type='text' value={enteredlastName} id='name' onChange={lastNameChangeHandler} onBlur={lastNameBlurHandler} />
          { lastNameHasError && <p className="error-text">Enter last name is required</p> }
        </div>
      </div>
      <div className={inputEmailClasses}>
        <label htmlFor='name'>E-Mail Address</label>
        <input type='text' value={enteredEmail} onChange={emailChangeHandler} onBlur={emailBlurHandler} id='name' />
        { emailHasError && <p className="error-text">Enter e-mail is required </p>}
      </div>
      <div className='form-actions'>
        <button disabled={!formIsValid}>Submit</button>
      </div>
    </form>
  );
};

export default BasicForm;

