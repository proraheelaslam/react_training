import { useState } from "react";
import useInput from "../hooks/use-input";

const SimpleInput = () => {

  const {
    value:enterName,
    hasError: nameInputHasError,
    isValid: enterNameIsValid,
    valueChangeHandler: nameChangeHandler,
    inputBlurHandler: nameBlurHandler,
    reset: resetInputName

  } =  useInput( value=> value.trim() !== '' );

  const {
    value:enterEmail,
    hasError: emailInputHasError,
    isValid: enteredEmailValid,
    valueChangeHandler: emailChangeHandler,
    inputBlurHandler: emailBlurHanlder,
    reset: resetInputEmail

  } =  useInput(value=> value.includes('@'));

  let formIsValid = false;
  if(enterNameIsValid && enteredEmailValid){
    formIsValid =  true;
  }
 

  const formSubmitHandler  = (event) => {
    event.preventDefault();
    
    if(!enterNameIsValid){
        return;
    } 
    resetInputName();
    resetInputEmail();
   

  }
 
  const inputClasses = nameInputHasError ? 'form-control invalid' : 'form-control';
  const inputEmailClasses = enteredEmailValid ? 'form-control invalid' : 'form-control';

  return (
    <form onSubmit={formSubmitHandler}>
      <div className={inputClasses}>
        <label htmlFor='name'>Your Name</label>
        <input type='text' id='name' value={enterName} onChange={nameChangeHandler} onBlur={nameBlurHandler} />
      </div>
      {
        nameInputHasError && <p className="error-text"> Name is required </p>
      }

      <div className={inputEmailClasses}>
        <label htmlFor='email'>Your Email</label>
        <input type='email' id='email' value={enterEmail} onChange={emailChangeHandler} onBlur={emailBlurHanlder} />
      </div>
      {
        emailInputHasError && <p className="error-text"> Email is required </p>
      }

      <div className="form-actions">
        <button disabled={!formIsValid}>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;
