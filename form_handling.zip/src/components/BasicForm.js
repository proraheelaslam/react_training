import useInput from "../hooks/use-input";

 const isNotEmpty = value => value.trim() !== "";
 const isEmail = value => value.includes('@');

const BasicForm = () => {


  const  { 
    value: firstNameValue,
    hasError: firstNameError,
    valueChangeHandler: firstNameChangeHandler,
    inputBlurHandler: firstNameInputBlurHandler,
    isValid: firstNameIsValid,
    reset: firstNameResetHandler,

  } = useInput(isNotEmpty);

  const {
    value: lastNameValue,
    hasError: lastNameError,
    valueChangeHandler: lastNameChangeHandler,
    inputBlurHandler: lastNameInputBlurHandler,
    isValid:lastNameIsValid,
    reset: lastNameResetHandler,
  } = useInput(isNotEmpty);

  const {
    value: emailValue,
    hasError: emailError,
    valueChangeHandler: emailChangeHandler,
    inputBlurHandler: emailInputBlurHandler,
    isValid:emailIsValid,
    reset: emailResetHandler, 
  } = useInput(isEmail);

  const inputFirstNameClasses = firstNameError ? 'form-control invalid' : 'form-control';
  const inputLastNameClasses = lastNameError ? 'form-control invalid' : 'form-control';
  const inputEmailClasses = emailError ? 'form-control invalid' : 'form-control';

  let formIsValid = false;
  if(firstNameIsValid && lastNameIsValid && emailIsValid) {
    formIsValid = true
  } 
  const submitHandler = (e)=> {
    e.preventDefault();
    
    if(!formIsValid){
      return;
    } 
    console.log(firstNameValue, lastNameValue, emailValue);
    firstNameResetHandler();
    lastNameResetHandler();
    emailResetHandler();


  } 
  return (

    <form onSubmit={submitHandler}>
      <div className='control-group'>
        <div className={inputFirstNameClasses}>
          <label htmlFor='name'>First Name</label>
          <input type='text' value={firstNameValue} id='name'  onChange={firstNameChangeHandler} onBlur={firstNameInputBlurHandler} />
          { firstNameError && <p className="error-text">First name is required</p> }
        </div>
        <div className={inputLastNameClasses}>
          <label htmlFor='name'>Last Name</label>
          <input type='text' value={lastNameValue} id='name' onChange={lastNameChangeHandler} onBlur={lastNameInputBlurHandler} />
          { lastNameError && <p className="error-text">Last name is required</p> }
        </div>
      </div>
      <div className={inputEmailClasses}>
        <label htmlFor='name'>E-Mail Address</label>
        <input type='text' value={emailValue}  id='name' onChange={emailChangeHandler} onBlur={emailInputBlurHandler} />
        { emailError && <p className="error-text">Email is required</p> }
      </div>
      <div className='form-actions'>
        <button disabled={!formIsValid}>Submit</button>
      </div>
    </form>
  );
};

export default BasicForm;

