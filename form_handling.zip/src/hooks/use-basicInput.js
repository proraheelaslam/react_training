import { useState } from "react";

 const useBasicInput = (validateValue) => {

    const [ enteredValue, setEnteredValue ] = useState("");
    const [ isTouched , setIsTouched ] = useState(false);
    const valueIsValid = validateValue(enteredValue);
    const hasError = isTouched && !valueIsValid;
    const valueChangeHandler = (event) => {
        setEnteredValue(event.target.value);   
    }
    const valueBlurHandler = (event) => {
        setIsTouched(true);
    }
    const reset = () => {
        setEnteredValue('');
        setIsTouched(false);
    }
    return {
        value: enteredValue,
        valueIsValid,
        hasError,
        valueChangeHandler,
        valueBlurHandler,
        reset
    }
 }
 export default useBasicInput;
